#Running on a particular treadmill you burn 4.2 calories per minute. Write a program that uses a loop to display the
#number of calories burned after 10, 15, 20, 25, and 30 minutes.

cal = 4.2 * 5
time = 5
for i in range(5):
    cal = cal + 21
    time = time + 5
    print(cal," calories burned after ", time, " minutes")
