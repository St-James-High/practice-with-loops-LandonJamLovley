#Write a program that asks the user to enter the amount that he or she has budgeted for a month. A loop should then
#promt the user to enter each of his or her expenses for the month and keep a running total. When the loop finishes,
#the program should display the amount that the user is over or under budget.

i = 0
total = 0
budget = int(input("How much do you PLAN to budget this year?"))
for i in range(12):
    amm = int(input("How much have you budgeted this month?"))
    total = total + amm
if budget > total:
   print ("You are under the budget of:", budget)
if budget < total:
    print("You are over your budget of:", budget)
if budget == total:
    print("You met your budget of:", budget)
